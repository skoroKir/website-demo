var creditForm_OBS_Pack01 =
{
  "schema": {
    "field": {
      "id": "line1",
      "type": "string",
      "title": "Your text for credit line:",
      "name": "input1"
    }
  },
  "form": [
    {
      "id": "creditLine",
      "htmlClass": "creditLine",
      "key": "field"
    },
    // {
    //   "type": "submit",
    //   "title": "Submit"
    // },
    // {
    //   "id": "animOut",
    //   "type": "submit",
    //   "title": "Animate Out",
    //   // "onClick": function (evt) {
    //   //   evt.preventDefault();
    //   //   alert('Thank you!');
    //   // }
      
    // }
    
  ]
}